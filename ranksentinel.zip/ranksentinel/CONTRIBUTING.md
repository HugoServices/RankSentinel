# Contributing

Thank you for considering a contribution!

1. Open an issue describing the bug or proposed feature.
2. Fork the repository and create a focused branch.
3. Follow WordPress coding and security practices: validate input, escape output, check capabilities and use nonces for admin actions.
4. Test changes on a local WordPress installation.
5. Open a pull request describing the change and testing steps.

Please do not submit credentials, personal data or private site URLs in issues.
